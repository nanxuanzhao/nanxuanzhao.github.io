Compicon1K dataset, consisting of 1000 compound icons annotated with semantic labels (i.e., concepts).

If you use our data, please cite the following paper:

===============================Citation===============================
@article{ZhaoCHI2020, 
    author = {Nanxuan Zhao and Nam Wook Kim and Laura Mariah Herman and Hanspeter Pfister and Rynson W.H. Lau and Jose Echevarria and Zoya Bylinskii}, 
    title = {ICONATE: Automatic Compound Icon Generation and Ideation}, 
    booktitle = {Proceedings of the 2020 CHI Conference on Human Factors in Computing Systems}, 
    year = {2020} 
}
======================================================================