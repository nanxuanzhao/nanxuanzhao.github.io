Sources:

Headings from 1st row of spreadsheet:
- PPT: Microsoft's PowerPoint (v16.27) 
- EMOJI: Unicode Emoji (v12.0) accessed at https://unicode.org/emoji/charts/full-emoji-list.html (Aug 2019)
- NounProject: accessed at https://thenounproject.com (Aug 2019)
- Mixed: combining Emoji & IPNP sources
- IPNP: International Picture Naming Project accessed at https://crl.ucsd.edu/experiments/ipnp/method/getdata/getdata.html
- IPNP - 7 languages: https://crl.ucsd.edu/experiments/ipnp/7lgpno.html
- Subtlexus: based on Brysbaert and New (2009) accessed at http://www.lexique.org/
- UCAL: University of Calgary (Language Processing Lab) Picture Classification Data for 288 English Concepts accessed at https://psyc.ucalgary.ca/languageprocessing/node/22
- McRae: McRae Cognitive Science Lab Feature norms accessed at https://sites.google.com/site/kenmcraelab/norms-data 

Headings from 2nd-3rd row of spreadsheet:
- PPT category: for icons that could be (manually) visually matched to icons in our dataset, this is the category PPT uses for these icons
- EMOJI name & category: EMOJI name and category for icons whose concept name matches the EMOJI name, or if no exact match, then the EMOJI with the most similar visual appearance (manually verified)
- # available icons on NounProject: at the time when the search was done (Aug 2019), this is the number of search results returned when using the concept name as a text query; numbers constantly changing, but the relative counts may be meaningful 
- other labels used: if the IPNP or EMOJI names had related concepts that visually matched and were merged with the final concept name

References (if you use the data from corresponding parts of the spreadsheet, please cite):

For IPNP and IPNP - 7 languages:
(1) Szekely, A., D'Amico, S., Devescovi, A., Federmeier, K., Herron, D., Iyer, G., Jacobsen, T., Arévalo, A. L., Vargha, A., & Bates, E., 2005. Timed action and object naming. Cortex, 41(1), pp.7-25.
(2) Szekely, A., Jacobsen, T., D'Amico, S., Devescovi, A., Andonova, E., Herron, D., Lu, C. C., Pechmann, T., Pleh, C., Wicha, N., Federmeier, K., Gerdjikova, I., Gutierrez, G., Hung, D., Hsu, J., Iyer, G., Kohnert, K., Mehotcheva, T., Orozco-Figueroa, A., Tzeng, A., Tzeng, O., Arevalo, A., Vargha, A., Butler, A. C., Buffington, R., & Bates, E., 2004. A new on-line resource for psycholinguistic studies. Journal of memory and language, 51(2), pp.247-250.
(3) Szekely, A., D'Amico, S., Devescovi, A., Federmeier, K., Herron, D., Iyer, G., Jacobsen, T., & Bates, E., 2003. Timed picture naming: Extended norms and validation against previous studies. Behavior Research Methods, Instruments, & Computers, 35(4), pp.621-633.
(4) BBates, E., D'Amico, S., Jacobsen, T., Szekely, A., Andonova, E., Devescovi, A., Herron, D., Lu, C. C., Pechmann, T., Pleh, C., Wicha, N., Federmeier, K., Gerdjikova, I., Gutierrez, G., Hung, D., Hsu, J., Iyer, G., Kohnert, K., Mehotcheva, T., Orozco-Figueroa, A., Tzeng, A., & Tzeng, O., 2003. Timed picture naming in seven languages. Psychonomic bulletin & review, 10(2), pp.344-380.

For Subtlexus:
(5) Brysbaert, M. & New, B. (2009) Moving beyond Kucera and Francis: A Critical Evaluation of Current Word Frequency Norms and the Introduction of a New and Improved Word Frequency Measure for American English. Behavior Research Methods, 41 (4), 977-990. 

For UCAL:
(6) Taikh, A., Hargreaves, I.S., Yap, M.J. and Pexman, P.M., 2015. Semantic classification of pictures and words. The Quarterly Journal of Experimental Psychology, 68(8), pp.1502-1518.

For McRae:
(7) McRae, K., Cree, G.S., Seidenberg, M.S. and McNorgan, C., 2005. Semantic feature production norms for a large set of living and nonliving things. Behavior research methods, 37(4), pp.547-559.

