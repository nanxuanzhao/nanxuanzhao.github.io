1. Install theano and keras

pip install theano==0.8.2
pip install keras==1.2.0


2. To test the model

THEANO_FLAGS=device0 python test.py


===============================Citation===============================
@article{ZhaoSIG2018,
    author = {Nanxuan Zhao and Ying Cao and Rynson W.H. Lau},
    title = {What Characterizes Personalities of Graphic Designs?},
    journal = {ACM Transactions on Graphics (Proc. of SIGGRAPH 2018)},
    volume = {37},
    issue = {4},
    year = {2018}
}
======================================================================